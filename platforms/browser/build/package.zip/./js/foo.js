const Foo = function() {
  this.name = "bar";
};

module.exports = Foo;